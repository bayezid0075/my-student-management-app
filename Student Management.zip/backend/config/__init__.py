import pymysql

# Install PyMySQL as MySQLdb to work with Django
pymysql.install_as_MySQLdb()
